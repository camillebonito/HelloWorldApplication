﻿Public Class HelloWorld

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtOutput.Text = "   HELLO WORLD!"

    End Sub
End Class
